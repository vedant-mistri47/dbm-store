export function Image(url) {
  return `https://api-test.digibulkmarketing.com/${url}`
} 